// Importing the packages required for the project.    

const express = require('express');  
const app = express();


require('dotenv').config();
  
app.set('port', process.env.PORT || 3000);

app.use(express.json({extended: true}));



//Routes pages
//app.use('/', require('./src/frontend/routes'));

//Route api
app.use('/api/clientes', require('./src/api/clientes/routes'));
app.use('/api/empleados', require('./src/api/empleados/routes'));
app.use('/api/personas', require('./src/api/personas/routes'));
app.use('/api/recursos', require('./src/api/recursos/routes'));
app.use('/api/registro', require('./src/api/registro/routes'));
app.use('/api/usuarios', require('./src/api/usuarios/routes'));
app.use('/api/planilla', require('./src/api/planilla/routes'));
app.use('/api/bitacoras', require('./src/api/bitacoras/routes'));

//Starting server
app.listen(app.get('port'), () => console.log(`server on port http://localhost:${app.get('port')}`));

module.exports = app;